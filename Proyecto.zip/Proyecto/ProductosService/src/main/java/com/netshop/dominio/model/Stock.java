package com.netshop.dominio.model;

public class Stock {
}
